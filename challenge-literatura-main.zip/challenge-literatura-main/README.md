# Practicando Spring Boot: Challenge Literatura
Este proyecto es construido como parte del Challenge Literatura de Alura Latam y ONE Oracle Next Education

## Tecnologías usadas
* Java
* Spring Boot
* PostgreSQL